#pragma once
#include "std_lib_facilities.h"
#include <cmath>

int randomWithLimits(int ovreGrense, int nedreGrense);