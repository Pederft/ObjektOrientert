
#include "canonball.h"
#include "utilities.h"

//------------------------------------------------------------------------------'



int main() {
    
    /*printVektor(getVelocityVector(27.5, 15.64));

    cout << getDistanceTraveled(13.8728, 7.22175) << endl;

    cout << targetPractice(25.5, 13.8728, 7.22175) << endl;*/

    //cout << checkIfDistanceToTargetIsCorrect() << endl;

    /*for( int i =0; i<10; i++){
        cout << randomWithLimits(0, 20) << endl;
    }*/
    
    playTargetPractice();

    return 0;
}


//------------------------------------------------------------------------------
