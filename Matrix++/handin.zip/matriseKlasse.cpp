#include "matriseKlasse.h"

double Matrix::get(int row, int col) const {
    assert(row >= 0 && col >= 0);
    return m_data[row][col];
}

void Matrix::set(int row, int col, double value){
    assert(row >= 0 && col >= 0);
    m_data[row][col] = value;
}

int Matrix::getRows() const {
    return rows;
}

int Matrix::getColumns() const {
    return col;
}

//Overlaster << operatoren:
std::ostream& operator<<(std::ostream& os, const Matrix& matrix){
    for(int i = 0; i < matrix.getRows(); i++){
        for(int k = 0; k < matrix.getColumns(); k++){
            os << matrix.get(i, k) << "\t";
        }
        os << std::endl;
    }
    return os;
}