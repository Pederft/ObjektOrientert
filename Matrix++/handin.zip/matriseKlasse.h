#pragma once
#include <iostream>
#include <cassert>


class Matrix{
    private:
        int rows;
        int col;
        double** m_data;

    public:
        Matrix(int nRows, int nCol) : rows{nRows}, col{nCol} {
            //Sjekker om input er gyldige:
            assert(nRows > 0 && nCol > 0);

            // Alloker minne for matrisen og sett alle elementer til 0
            m_data = new double*[rows];
            for (int i = 0; i < rows; ++i) {
                m_data[i] = new double[col];
                for (int j = 0; j < col; ++j) {
                    m_data[i][j] = 0.0;
                }
            }
        }

        explicit Matrix(int nRows) : Matrix(nRows, nRows){
            //Nå trenger vi kun å endre på diagonal-verdiene til null-matrisen:
            for(int i = 0; i<nRows; i++){
                m_data[i][i] = 1.0;
            }
        }

        double get(int row, int col) const;
        void set(int row, int col, double value);
        int getRows() const;
        int getColumns() const;

        //Lager destruktør for å frigjøre minne
        ~Matrix(){
            for(int i =0; i< rows; i++){
                delete[] m_data[i];
            }
            delete[] m_data;
        }   
};

std::ostream& operator<<(std::ostream& os, const Matrix& matrix);


