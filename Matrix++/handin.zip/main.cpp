

#include "dynMinne.h"
#include "matriseKlasse.h"


//------------------------------------------------------------------------------'



int main() {
    
    //createFibonacci();

    Matrix mat(4,4);
    mat.set(2,2, 8);

    Matrix A{4};


    std::cout << mat;

    std::cout << "\n\n" << std::endl;

    std::cout << A << std::endl;


    return 0;
}

//------------------------------------------------------------------------------
