#include "Card.h"

string suitToString(Suit type){
    return nameSuitMap.at(type);
}

string rankToString(Rank type){
    return nameRankMap.at(type);
}


Card::Card(Suit suit, Rank rank): s{suit}, r{rank}{}

