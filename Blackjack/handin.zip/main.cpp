
#include "Card.h"
#include "std_lib_facilities.h"

//------------------------------------------------------------------------------'


int main() {
    
    Card c{Suit::spades, Rank::ace}; 
    cout << c.toString() << '\n'; 
    return 0;
}

//------------------------------------------------------------------------------

